package com.sunhours.seasonalclock;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** Local, offline seasonal clock. No Android permissions or Internet connectivity required. */
public final class MainActivity extends Activity {
    private WebView clock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(12, 19, 34));
        getWindow().setNavigationBarColor(Color.rgb(12, 19, 34));
        clock = new WebView(this);
        WebSettings settings = clock.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        clock.setWebViewClient(new WebViewClient());
        clock.setWebChromeClient(new WebChromeClient());
        setContentView(clock);
        clock.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onDestroy() {
        if (clock != null) {
            clock.destroy();
            clock = null;
        }
        super.onDestroy();
    }
}

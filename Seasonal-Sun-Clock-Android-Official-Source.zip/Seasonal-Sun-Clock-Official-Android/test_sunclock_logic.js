const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const html=fs.readFileSync(process.argv[2] || '/mnt/data/seasonal-clock-v2/index.html','utf8');
const code=html.match(/<script>([\s\S]*?)<\/script>/)[1];
new vm.Script(code,{filename:'seasonal-clock.js'});
const elements={};
function el(id){return elements[id]??=( {
 id,value:'',innerHTML:'',textContent:'',style:{},attributes:{},events:{},children:[],disabled:false,
 classList:{add(){},remove(){},toggle(){}},
 addEventListener(name,fn){this.events[name]=fn},setAttribute(name,v){this.attributes[name]=v},
 appendChild(child){this.children.push(child)},
 });}
const document={getElementById:el,createElementNS:(ns,tag)=>el('__node_'+Object.keys(elements).length)};
const ctx={document,console,Date,Math,Number,JSON,String,Intl,Error,Set,Object,Array,parseInt,setInterval(){},navigator:{},location:{protocol:'file:'}};
vm.createContext(ctx);
vm.runInContext(code,ctx,{timeout:5000});
const cleanNumber=(id)=>Number(el(id).textContent.split(' ')[0].replace(' דק׳',''));
function check(label){
 for(const id of ['civil-time','solar-time','sunrise','sunset','day-hour','night-hour','solar-mode']){
 assert.ok(el(id).textContent, label+': '+id+' should be populated')
 }
 const d=cleanNumber('day-hour'),n=cleanNumber('night-hour');
 assert.ok(d>30 && d<100 && n>30 && n<100,`hours out of expected bounds: ${d},${n}`);
 assert.ok(Math.abs(d+n-120)<6,`day+night hours not ~120: ${d+n}`);
 console.log(label,'PASS','rise='+el('sunrise').textContent,'set='+el('sunset').textContent,'day='+d,'night='+n,'solar='+el('solar-time').textContent)
}
check('live');
el('sim-date').value='2026-06-21';el('sim-time').value='12:00';el('sim-date').events['change'](); check('summer 2026');const summer=cleanNumber('day-hour');
el('sim-date').value='2026-12-21';el('sim-time').value='12:00';el('sim-time').events['change']();check('winter 2026');const winter=cleanNumber('day-hour');assert.ok(summer>winter+15,`seasonal difference ${summer-winter}`);
el('city').value='eilat';el('city').events['change']({target:el('city')});check('Eilat');
el('city').value='haifa';el('city').events['change']({target:el('city')});check('Haifa');
el('city').value='custom';el('latitude').value='31.7683';el('longitude').value='35.2137';el('city').events['change']({target:el('city')});check('custom Jerusalem');
console.log('ALL JAVASCRIPT LOGIC CHECKS PASS');

#!/usr/bin/env bash
set -euo pipefail
APK="app/build/outputs/apk/debug/app-debug.apk"
PKG="com.sunhours.seasonalclock"
[ -s "$APK" ]
adb wait-for-device
adb install -r "$APK"
adb shell pm path "$PKG" | grep -q "package:"
adb logcat -c
adb shell am start -W -n "$PKG/.MainActivity" | tee ci/activity-launch.txt
grep -q 'Status: ok' ci/activity-launch.txt
sleep 8
# The Activity must remain alive and be frontmost.
PID="$(adb shell pidof "$PKG" | tr -d '')"
[ -n "$PID" ] || { echo 'The app crashed or did not start'; exit 1; }
adb shell dumpsys activity activities | grep -F "$PKG" > ci/activity-state.txt
# There must be no fatal exception in the app process.
if adb logcat -d -v brief | grep -A10 'FATAL EXCEPTION' | grep -q "$PKG"; then
  echo 'Android fatal exception detected'; exit 1
fi
adb exec-out screencap -p > ci/emulator-screenshot.png
[ -s ci/emulator-screenshot.png ]
echo 'PASS: APK installed, Activity started, process running, screenshot captured.'

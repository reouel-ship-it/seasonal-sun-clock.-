#!/usr/bin/env bash
set -euo pipefail
node test_sunclock_logic.js app/src/main/assets/index.html
python3 - <<'PYTEST'
from xml.etree import ElementTree as ET
for fn in ['app/src/main/AndroidManifest.xml','app/src/main/res/values/strings.xml']:
 ET.parse(fn)
print('Android XML syntax: OK')
PYTEST
